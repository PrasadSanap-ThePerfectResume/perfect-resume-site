package com.pvs.perfectresume.google;

public class Sample {
    public static void main(String[] arg){
        System.out.println("Hii");
    }
}
